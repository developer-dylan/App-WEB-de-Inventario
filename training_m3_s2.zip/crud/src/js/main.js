// When the page is ready
document.addEventListener('DOMContentLoaded', () => {
  const buttons = document.querySelectorAll('.form-toggle');
  const sections = document.querySelectorAll('.form-section');

  // Show the selected form
  buttons.forEach(button => {
    button.addEventListener('click', () => {
      const target = button.dataset.target;

      sections.forEach(section => {
        section.classList.remove('active');
        if (section.id === target) {
          section.classList.add('active');
        }
      });

      if (target === 'list') {
        showInventory();
      }
    });
  });

  // Product array
  let products = [];

  // Add product
  const addForm = document.querySelector('#add form');
  addForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const id = addForm.querySelectorAll('input')[0].value.trim();
    const name = addForm.querySelectorAll('input')[1].value.trim();
    const category = addForm.querySelectorAll('input')[2].value.trim();
    const price = parseFloat(addForm.querySelectorAll('input')[3].value);

    if (!id || !name || !category || isNaN(price)) {
      alert('Llena todos los campos bien.');
      return;
    }

    if (products.some(p => p.id === id)) {
      alert('ID repetido.');
      return;
    }

    products.push({ id, name, category, price });
    addForm.reset();
    alert('Producto agregado.');
  });

  // Delete product
  const deleteForm = document.querySelector('#delete form');
  deleteForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const id = deleteForm.querySelector('input').value.trim();
    const index = products.findIndex(p => p.id === id);

    if (index === -1) {
      alert('No encontrado.');
      return;
    }

    products.splice(index, 1);
    deleteForm.reset();
    alert('Producto eliminado.');
  });

  // Update product
  const updateForm = document.querySelector('#update form');
  updateForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const id = updateForm.querySelectorAll('input')[0].value.trim();
    const newPrice = parseFloat(updateForm.querySelectorAll('input')[1].value);

    if (!id || isNaN(newPrice)) {
      alert('Escribe ID y precio.');
      return;
    }

    const product = products.find(p => p.id === id);
    if (!product) {
      alert('No encontrado.');
      return;
    }

    product.price = newPrice;
    updateForm.reset();
    alert('Precio actualizado.');
  });

  // Show product list
  function showInventory() {
    const list = document.getElementById('inventoryList');
    list.innerHTML = '';

    if (products.length === 0) {
      const li = document.createElement('li');
      li.textContent = 'Inventario vacío.';
      list.appendChild(li);
      return;
    }

    products.forEach(p => {
      const li = document.createElement('li');
      li.textContent = `${p.id} - ${p.name} - ${p.category} - $${p.price.toFixed(2)}`;
      list.appendChild(li);
    });
  }
});
